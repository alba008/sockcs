import { useEffect, useState } from "react"
import { fetchProducts } from "../api"
import ProductCard from "./ProductCard"
export default function ProductGrid({ filter = {} }) {
  const [data, setData] = useState({ results: [] })
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    setLoading(true)
    fetchProducts(filter).then(d => { setData(d); setLoading(false) })
  }, [JSON.stringify(filter)])
  if(loading) return <div style={{ padding:"60px", textAlign:"center", fontSize:"12px", letterSpacing:"2px" }}>LOADING CITY SYSTEM...</div>
  return <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(280px, 1fr))", gap:"24px" }}>{data.results.map(p => <ProductCard key={p.id} product={p} />)}</div>
}