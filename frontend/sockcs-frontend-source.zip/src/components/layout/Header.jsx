import { Link } from "react-router-dom"
import { useCart } from "../../context/CartContext"

export default function Header() {
  const { count, setIsOpen } = useCart()
  return (
    <header style={{ borderBottom:"1px solid #EAE8E3", background:"#fff", position:"sticky", top:0, zIndex:20, width:"100vw", marginLeft:"calc(-50vw + 50%)" }}>
      <div style={{ maxWidth:"1440px", margin:"0 auto", padding:"20px 40px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
       {/* HEADER - FULL WIDTH */}
      <div style={{ position:"sticky", top:0, zIndex:50, background:"rgba(250,249,246,0.95)", backdropFilter:"blur(12px)", borderBottom:"1px solid rgba(0,0,0,0.08)", width:"100%" }}>
          <div style={{ display:"flex", gap:"32px", alignItems:"center" }}>
            <Link to="/" style={{ fontWeight:900, letterSpacing:"-0.5px", fontSize:"18px", textDecoration:"none", color:"#000" }}>SOCKCS</Link>
            <div style={{ display:"flex", gap:"24px", fontSize:"11px", letterSpacing:"1.8px", textTransform:"uppercase" }} className="hide-mobile">
              <Link to="/shop" style={{ color:"#000", textDecoration:"none" }}>Shop Kits</Link>
              <Link to="/shop?category=socks" style={{ color:"#000", textDecoration:"none" }}>Socks</Link>
              <a href="#story" style={{ color:"#000", textDecoration:"none" }}>Story</a>
            </div>
          </div>
          <div style={{ display:"flex", gap:"16px", alignItems:"center" }}>
            <span style={{ fontSize:"10px", letterSpacing:"2px", textTransform:"uppercase", opacity:0.6 }}>NYC EST 2025</span>
            <Link to="/shop" style={{ background:"#000", color:"#fff", borderRadius:"999px", padding:"0 20px", height:"32px", display:"flex", alignItems:"center", fontSize:"11px", letterSpacing:"1px", textTransform:"uppercase", textDecoration:"none" }}>Shop Now</Link>
          </div>
        </div>
      </div>
        <div style={{ display:"flex", gap:"20px", alignItems:"center" }}>
          <div style={{ fontSize:"10px", letterSpacing:"2px" }}>CITY SYSTEM / 11377</div>
          <button onClick={() => setIsOpen(true)} style={{ background:"#000", color:"#fff", border:"none", padding:"8px 14px", fontSize:"11px", letterSpacing:"1px", cursor:"pointer", borderRadius:"20px" }}>
            CART ({count})
          </button>
        </div>
      </div>
    </header>
  )
}
