export default function Footer() {
    return (
      <footer style={{ textAlign:"center", padding:"40px", fontSize:"10px", letterSpacing:"2px", color:"#999", borderTop:"1px solid #EAE8E3", width:"100vw", marginLeft:"calc(-50vw + 50%)", background:"#fff" }}>
        SOCKCS // CITY SYSTEM // BUILT LINE BY LINE // BROOKLYN NY
        <span className="font-hand" style={{ fontSize:"14px", marginLeft:"8px" }}>packaged by hand ♡</span>
      </footer>
    )
  }