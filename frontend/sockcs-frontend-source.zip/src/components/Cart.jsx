import { useCart } from "../context/CartContext"

export default function Cart() {
  const { cart, isOpen, setIsOpen, removeFromCart, updateQty, total } = useCart()

  if(!isOpen) return null

  return (
    <div style={{ position:"fixed", inset:0, zIndex:50, display:"flex", justifyContent:"flex-end" }}>
      <div style={{ position:"absolute", inset:0, background:"rgba(0,0,0,0.4)" }} onClick={() => setIsOpen(false)} />
      <div style={{ position:"relative", width:"420px", background:"#fff", height:"100vh", display:"flex", flexDirection:"column", borderLeft:"1px solid #EAE8E3" }}>
        <div style={{ padding:"24px", borderBottom:"1px solid #EAE8E3", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <h2 style={{ margin:0, fontSize:"13px", letterSpacing:"2px", textTransform:"uppercase" }}>CART ({cart.length})</h2>
          <button onClick={() => setIsOpen(false)} style={{ background:"none", border:"1px solid #EAE8E3", padding:"6px 12px", cursor:"pointer", fontSize:"11px" }}>CLOSE</button>
        </div>

        <div style={{ flex:1, overflowY:"auto", padding:"24px" }}>
          {cart.length === 0 ? (
            <p style={{ fontSize:"12px", letterSpacing:"1px", textAlign:"center", marginTop:"60px", color:"#999" }}>YOUR CITY SYSTEM IS EMPTY</p>
          ) : (
            cart.map(item => (
              <div key={item.id} style={{ display:"flex", gap:"16px", marginBottom:"24px", borderBottom:"1px solid #FAF9F6", paddingBottom:"24px" }}>
                <img src={item.image_url} style={{ width:"80px", height:"100px", objectFit:"cover", background:"#FAF9F6" }} />
                <div style={{ flex:1 }}>
                  <h4 style={{ margin:"0 0 4px 0", fontSize:"12px", letterSpacing:"1px", textTransform:"uppercase" }}>{item.name}</h4>
                  <p style={{ margin:0, fontSize:"12px" }}>${item.price}</p>
                  <div style={{ marginTop:"12px", display:"flex", gap:"8px", alignItems:"center" }}>
                    <button onClick={() => updateQty(item.id, item.qty - 1)} style={{ width:"28px", height:"28px", border:"1px solid #EAE8E3", background:"#fff", cursor:"pointer" }}>-</button>
                    <span style={{ fontSize:"12px", width:"20px", textAlign:"center" }}>{item.qty}</span>
                    <button onClick={() => updateQty(item.id, item.qty + 1)} style={{ width:"28px", height:"28px", border:"1px solid #EAE8E3", background:"#fff", cursor:"pointer" }}>+</button>
                    <button onClick={() => removeFromCart(item.id)} style={{ marginLeft:"12px", fontSize:"10px", background:"none", border:"none", textDecoration:"underline", cursor:"pointer" }}>REMOVE</button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div style={{ padding:"24px", borderTop:"1px solid #EAE8E3", background:"#FAF9F6" }}>
            <div style={{ display:"flex", justifyContent:"space-between", fontSize:"12px", marginBottom:"8px" }}><span>SUBTOTAL</span><span>${total.toFixed(2)}</span></div>
            <div style={{ display:"flex", justifyContent:"space-between", fontSize:"12px", marginBottom:"16px" }}><span>SHIPPING</span><span>$8.00</span></div>
            <div style={{ display:"flex", justifyContent:"space-between", fontSize:"13px", fontWeight:700, marginBottom:"20px" }}><span>TOTAL</span><span>${(total + 8).toFixed(2)}</span></div>
            <button style={{ width:"100%", padding:"16px", background:"#000", color:"#fff", border:"none", fontSize:"12px", letterSpacing:"2px", cursor:"pointer" }} onClick={() => alert("Checkout v2 — Stripe next step!")}>
              CHECKOUT — ${(total + 8).toFixed(2)}
            </button>
            <p style={{ fontSize:"10px", color:"#999", textAlign:"center", marginTop:"12px", letterSpacing:"1px" }}>BUILT LINE BY LINE IN BROOKLYN NY</p>
          </div>
        )}
      </div>
    </div>
  )
}