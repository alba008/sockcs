// src/pages/Home.jsx - REAL API + NO TAILWIND + HANDWRITTEN STICKERS
import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import { useCart } from "../context/CartContext"

const API = "http://127.0.0.1:8000"

export default function Home() {
  const [kits, setKits] = useState([])
  const [socks, setSocks] = useState([])
  const [best, setBest] = useState([])
  const { addToCart } = useCart()

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [k, s, b] = await Promise.all([
          fetch(`${API}/api/products/?category=kits`).then(r=>r.json()).catch(()=>[]),
          fetch(`${API}/api/products/?category=socks`).then(r=>r.json()).catch(()=>[]),
          fetch(`${API}/api/products/?ordering=-sales`).then(r=>r.json()).catch(()=>[])
        ])
        setKits(Array.isArray(k) ? k : k.results || [])
        setSocks(Array.isArray(s) ? s : s.results || [])
        setBest(Array.isArray(b) ? b.slice(0,3) : (b.results||[]).slice(0,3))
      } catch {}
    }
    fetchAll()
  }, [])

  const displayKits = kits.length ? kits.slice(0,3) : best.length ? best : []

  return (
    <div style={{ background:"#FAF9F6", color:"#000", overflowX:"hidden", fontFamily:"Inter, system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Caveat:wght@600&family=Permanent+Marker&display=swap');
      `}</style>

      

      {/* HERO */}
      <div style={{ maxWidth:"1440px", margin:"0 auto", padding:"0 24px" }}>
        <div style={{ display:"grid", gridTemplateColumns:"1.15fr 0.85fr", borderLeft:"1px solid rgba(0,0,0,0.08)", borderRight:"1px solid rgba(0,0,0,0.08)", borderBottom:"1px solid rgba(0,0,0,0.08)" }}>
          <div style={{ padding:"40px", display:"flex", flexDirection:"column", justifyContent:"space-between" }}>
            <div>
              <div style={{ fontSize:"10px", letterSpacing:"2.2px", textTransform:"uppercase", opacity:0.6, marginBottom:"32px" }}>Brooklyn Made · EST 2025</div>
              <div style={{ fontFamily:"Instrument Serif, Georgia, serif", fontSize:"clamp(48px, 8vw, 92px)", lineHeight:0.85, letterSpacing:"-2px" }}>Nueva York</div>
              <div style={{ fontWeight:200, fontSize:"clamp(48px, 8vw, 92px)", lineHeight:0.85, letterSpacing:"-2px", textTransform:"uppercase" }}>Uniform</div>
              <div style={{ marginTop:"32px", fontSize:"14px", lineHeight:1.6, maxWidth:"360px" }}>Tee. Shorts. Socks. Designed in NYC.<br/>Worn by founder. Built as one fit.</div>
              <div style={{ marginTop:"32px", display:"flex", gap:"12px" }}>
                <Link to="/shop" style={{ background:"#000", color:"#fff", borderRadius:"999px", padding:"12px 28px", fontSize:"13px", textDecoration:"none" }}>Shop Kits $89</Link>
                <Link to="/shop?category=socks" style={{ border:"1px solid #000", borderRadius:"999px", padding:"12px 28px", fontSize:"13px", textDecoration:"none", color:"#000" }}>Shop Socks</Link>
              </div>
            </div>
            <div style={{ marginTop:"80px", borderTop:"1px solid rgba(0,0,0,0.08)", paddingTop:"16px", display:"flex", justifyContent:"space-between", fontSize:"10px", letterSpacing:"1.6px", textTransform:"uppercase", opacity:0.6 }}>
              <span>Look 01 / Brooklyn</span><span>240GSM Heavyweight · Woven Tag · Stripe Sock</span>
            </div>
          </div>
          <div style={{ background:"#EDEBE6", minHeight:"760px", position:"relative", overflow:"hidden" }}>
            <img src="https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800" alt="" style={{ width:"100%", height:"100%", objectFit:"cover", position:"absolute", inset:0 }} />
            {/* use your real hero: <img src="/src/assets/Brooklyn_sidewalk_walk.webp" /> */}
          </div>
        </div>
      </div>

      {/* KITS - REAL API */}
      <div id="kits" style={{ background:"#0a0a0a", color:"#fff", width:"100%", marginTop:"0" }}>
        <div style={{ maxWidth:"1440px", margin:"0 auto", padding:"56px 24px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end", marginBottom:"40px" }}>
            <div>
              <div style={{ fontSize:"10px", letterSpacing:"2px", textTransform:"uppercase", opacity:0.5 }}>Drop 01 — The Uniform</div>
              <div style={{ fontFamily:"Instrument Serif, Georgia, serif", fontSize:"56px", lineHeight:0.9, marginTop:"12px" }}>The Kits</div>
              <div style={{ fontSize:"13px", opacity:0.6, marginTop:"8px", maxWidth:"320px" }}>One tee, one bottom, one pair. No styling needed. Founder-worn everyday. Real products from API.</div>
            </div>
            <Link to="/shop" style={{ color:"#fff", fontSize:"11px", letterSpacing:"1px", textTransform:"uppercase", opacity:0.6 }}>Shop All →</Link>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(320px, 1fr))", gap:"20px" }}>
            {displayKits.map((p,i)=>(
              <div key={p.id||i} style={{ background:"#121212", border:"1px solid rgba(255,255,255,0.1)", borderRadius:"18px", overflow:"hidden" }}>
                <div style={{ position:"relative", aspectRatio:"4/5", background:"#1a1a1a" }}>
                  <img src={p.image || p.thumbnail || `https://picsum.photos/seed/${p.id}/600/800`} alt={p.name} style={{ width:"100%", height:"100%", objectFit:"cover" }} />
                  <div style={{ position:"absolute", top:"12px", left:"12px", display:"flex", gap:"8px" }}>
                    <span style={{ background:"#fff", color:"#000", borderRadius:"999px", padding:"4px 12px", fontSize:"10px", textTransform:"uppercase" }}>{i===0?"Bestseller":i===1?"New":"Limited"}</span>
                  </div>
                </div>
                <div style={{ padding:"16px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div><div style={{ fontSize:"14px", fontWeight:500 }}>{p.name || `Kit 0${i+1}`}</div><div style={{ fontSize:"11px", opacity:0.6 }}>{p.description?.slice(0,40) || "240 GSM · Woven Tag"}</div></div>
                  <button onClick={()=>addToCart && addToCart(p)} style={{ background:"#fff", color:"#000", borderRadius:"999px", border:0, padding:"0 16px", height:"32px", fontSize:"12px", cursor:"pointer" }}>${p.price||89} Add</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* HANDWRITTEN STICKER WALL - CREATIVE BOTTOM */}
      <div style={{ background:"#111", color:"#FAF9F6", width:"100%", padding:"64px 0", position:"relative", overflow:"hidden" }}>
        <div style={{ maxWidth:"1440px", margin:"0 auto", padding:"0 24px", position:"relative" }}>
          <div style={{ position:"absolute", top:"0", right:"40px", fontFamily:"Caveat, cursive", fontSize:"22px", transform:"rotate(8deg)", opacity:0.7 }}>made for sidewalks, not runways</div>
          
          <div style={{ display:"grid", gridTemplateColumns:"1.2fr 0.8fr", gap:"32px", alignItems:"end", marginTop:"40px" }}>
            <div>
              <span style={{ fontFamily:"Permanent Marker, cursive", fontSize:"14px", background:"#FFE600", color:"#000", padding:"6px 12px", transform:"rotate(-3deg)", display:"inline-block" }}>BROOKLYN TESTED</span>
              <div style={{ fontFamily:"Instrument Serif, Georgia, serif", fontSize:"72px", lineHeight:0.85, marginTop:"24px" }}>Worn<br/>in<br/>NYC</div>
              <div style={{ fontFamily:"Caveat, cursive", fontSize:"26px", lineHeight:1.1, maxWidth:"320px", marginTop:"24px" }}>every pair comes with a scuff from the lab. we walked in em first ♡</div>
              
              <div style={{ marginTop:"32px", display:"flex", flexWrap:"wrap", gap:"8px" }}>
                <span style={{ border:"1px solid rgba(255,255,255,0.3)", borderRadius:"999px", padding:"8px 16px", fontSize:"11px", textTransform:"uppercase", letterSpacing:"1px", transform:"rotate(-1deg)", display:"inline-block" }}>No slip</span>
                <span style={{ border:"1px solid rgba(255,255,255,0.3)", borderRadius:"999px", padding:"8px 16px", fontSize:"11px", textTransform:"uppercase", letterSpacing:"1px", transform:"rotate(2deg)", display:"inline-block" }}>Woven tag</span>
                <span style={{ background:"#fff", color:"#000", borderRadius:"999px", padding:"8px 16px", fontSize:"11px", textTransform:"uppercase", letterSpacing:"1px", fontWeight:500, transform:"rotate(-2deg)", display:"inline-block" }}>Packaged by hand ♡</span>
              </div>

              <div style={{ marginTop:"48px", borderTop:"1px solid rgba(255,255,255,0.1)", paddingTop:"24px", display:"flex", justifyContent:"space-between", fontFamily:"Caveat, cursive", fontSize:"20px", opacity:0.6 }}>
                <span>uniform notes: tee + shorts + stripe → done.</span>
              </div>
            </div>

            <div>
              <div style={{ background:"#FAF9F6", color:"#000", padding:"12px 12px 40px 12px", borderRadius:"4px", transform:"rotate(-2deg)", boxShadow:"0 20px 40px rgba(0,0,0,0.4)", position:"relative" }}>
                <div style={{ position:"absolute", top:"-12px", left:"50%", transform:"translateX(-50%) rotate(-2deg)", width:"80px", height:"24px", background:"rgba(255,255,255,0.4)", backdropFilter:"blur(4px)" }} />
                <div style={{ aspectRatio:"4/3", background:"#EFECE6", borderRadius:"4px", overflow:"hidden" }}>
                  <img src="https://images.unsplash.com/photo-1516257984-b1b4d3e6157d?w=600" style={{ width:"100%", height:"100%", objectFit:"cover" }} alt="" />
                </div>
                <div style={{ fontFamily:"Caveat, cursive", fontSize:"20px", textAlign:"center", marginTop:"12px" }}>Bed-Stuy → LES 11:42pm</div>
              </div>
              <div style={{ marginTop:"16px", display:"flex", gap:"8px", flexWrap:"wrap" }}>
                <div style={{ background:"#fff", color:"#000", borderRadius:"999px", padding:"6px 12px", fontFamily:"Permanent Marker, cursive", fontSize:"13px", transform:"rotate(4deg)" }}>240GSM HEAVY!!</div>
                <div style={{ background:"#000", border:"1px solid rgba(255,255,255,0.2)", borderRadius:"12px", padding:"8px 12px", fontFamily:"Caveat, cursive", fontSize:"18px", transform:"rotate(-1deg)" }}>ps: socks first, always.</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      
    </div>
  )
}