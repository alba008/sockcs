import axios from "axios";
const api = axios.create({ baseURL: "http://127.0.0.1:8000/api" });
export const fetchProducts = (params = {}) => api.get("/products/", { params }).then(r => r.data);
export const fetchProductBySlug = (slug) => api.get(`/products/${slug}/`).then(r => r.data);
export const fetchSiteImages = (loc="hero") =>
  fetch(`http://127.0.0.1:8000/api/site-images/?location=${loc}`).then(r=>r.json())