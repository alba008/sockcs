import { BrowserRouter, Routes, Route } from "react-router-dom"
import { CartProvider } from "./context/CartContext"
import Header from "./components/layout/Header"
import Footer from "./components/layout/Footer"
import Home from "./pages/Home"
import Shop from "./pages/Shop"
import ProductDetail from "./components/ProductDetail"
import Cart from "./components/Cart"

function AppContent() {
  return (
    <div style={{ background:"#FAF9F6", minHeight:"100vh", fontFamily:"Inter, system-ui, sans-serif", width:"100vw", overflowX:"hidden" }}>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/shop" element={<Shop />} />
        <Route path="/products/:slug" element={<ProductDetail />} />
      </Routes>
      <Cart />
      <Footer />
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <CartProvider>
        <AppContent />
      </CartProvider>
    </BrowserRouter>
  )
}